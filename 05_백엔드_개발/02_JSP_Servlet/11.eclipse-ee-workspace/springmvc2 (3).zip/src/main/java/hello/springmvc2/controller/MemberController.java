package hello.springmvc2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import hello.springmvc2.handler.MemberHandler;
import hello.springmvc2.model.Member;

/*
 * Controller : HTTP 요청을 받아 처리하는 컨트롤러
 * 				MVC 패턴에서 'C'에 해당
 * 
 * Spring MVC 흐름 
 * 	1) 클라이언트가 HTTP 요청
 *  2) DispatcherServelt이 요청을 받음
 *  3) HandlerMapping이 이 컨트롤러를 찾음
 *  4) 컨트롤러가 요청을 처리
 */
@Controller			// 이 클래스가 컨트롤러임을 Spring에게 알림(컴포넌트 스캔 대상)
@RequestMapping("/members")	// 이 컨트롤러의 기본 URL 경로 설정 (모든 메서드에 공통적용)
public class MemberController {

	@Autowired		//의존성 자동 주입 (Spring이 MemberHandler 객체를 자동으로 연결)
	private MemberHandler memberHandler; // 비즈니스 로직을 처리할 핸들러 
	
	/*
	 * 회원 목록 조회 
	 * GET /members
	 */
	@GetMapping("")		//GET 방식의 /members 요청을 이 메서드가 처리
	public String listMembers(Model model) { //Model 객체는 Spring이 자동으로 주입(view로 데이터 전달용) 
		System.out.println("=== MVC 흐름 시작 ===");
		System.out.println("1. 클라이언트 요청: GET /members");
		System.out.println("2. DispatcherServlet이 요청을 받음");
		System.out.println("3. HandlerMapping이 MemberController.listMembers()를 찾음");
		System.out.println("4. 핸들러 어댑터가 컨트롤러 메소드 실행");
		
		// 핸들러를 통해 비즈니스 로직 처리 (회원 목록 조회)
		List<Member> members = memberHandler.getAllMembers();
		
		// Model에 데이터 추가 
		// JSP에서 ${members}로 접근 가능 
		model.addAttribute("members", members);
		
		System.out.println("5. Model에 데이터 추가 완료");
		System.out.println("6. ViewResolver가 'member-list'를 /WEB-INF/views/member-list.jsp로 변환");
		System.out.println("7. View 반환: member-list");
		
		return "member-list";
	}
	
}












