package com.example.booksearch.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.booksearch.service.BookService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/*
 * 도서 검색 관련 요청을 처리하는 Controller
 * @RequestParam 
 */

@Slf4j		  // 로깅을 위한 Lombok 어노테이션
@Controller   // Spring MVC Controller로 등록
@RequiredArgsConstructor  // final 필드에 대한 생성자 자동 생성
public class BookController {

	private final BookService bookService;
	
	/*
	 * 페이지 라우팅
	 */
	
	/*
	 * 메인 페이지 
	 */
	@GetMapping("/")
	public String home() {
		log.info("메인 페이지 요청");
		return "index";
	}
	
	/*
	 * @RequestParam train 페이지
	 */
	@GetMapping("/request-param-test")
	public String requestParamTest() {
		log.info("@RequestParam train 페이지 요청");
		return "request-param-test";
	}
}
















