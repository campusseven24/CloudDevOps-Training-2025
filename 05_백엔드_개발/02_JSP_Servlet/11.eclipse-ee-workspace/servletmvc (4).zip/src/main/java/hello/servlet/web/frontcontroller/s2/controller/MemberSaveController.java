package hello.servlet.web.frontcontroller.s2.controller;

import java.io.IOException;

import hello.servlet.basic.domain.member.Member;
import hello.servlet.basic.domain.member.MemberRepository;
import hello.servlet.web.frontcontroller.MyView;
import hello.servlet.web.frontcontroller.s2.Controller;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/*
 * 회원 정보를 저장하는 컨트롤러 
 * 	- 폼에서 전송된 데이터를 받아서 저장
 * 	- 저장 결과를 JSP로 전달하여 화면 랜더링 
 */

public class MemberSaveController implements Controller {

	//회원 정보 관리하는 Repository (싱글폰 패턴)
	private MemberRepository memberRepository = MemberRepository.getInstance();
	
	@Override
	public MyView process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1. 요청 파라미터에서 데이터 추출
		String username = request.getParameter("username");
		int age = Integer.parseInt(request.getParameter("age"));
		
		//2. 비지니스 로직 처리
		Member member = new Member(username, age);
		memberRepository.save(member);
		
		//3. Model에 데이터 저장
		request.setAttribute("member", member);
		
		//4. View로 포워딩 - 저장 결과를 보여줄 JSP 경로 설정
		// 컨트롤러가 View 랜더링 책임에서 해당
		return new MyView("/WEB-INF/views/save-result.jsp");
	}

}






