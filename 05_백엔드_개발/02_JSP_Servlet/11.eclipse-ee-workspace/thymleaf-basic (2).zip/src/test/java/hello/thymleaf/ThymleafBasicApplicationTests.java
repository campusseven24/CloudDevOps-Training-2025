package hello.thymleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymleafBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
