package com.example.booksearch.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.booksearch.model.Book;
import com.example.booksearch.service.BookService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/*
 * 도서 검색 관련 요청을 처리하는 Controller
 * @RequestParam 
 */

@Slf4j		  // 로깅을 위한 Lombok 어노테이션
@Controller   // Spring MVC Controller로 등록
@RequiredArgsConstructor  // final 필드에 대한 생성자 자동 생성
public class BookController {

	private final BookService bookService;
	
	/*
	 * 페이지 라우팅
	 */
	
	/*
	 * 메인 페이지 
	 */
	@GetMapping("/")
	public String home() {
		log.info("메인 페이지 요청");
		return "index";
	}
	
	/*
	 * @RequestParam train 페이지
	 */
	@GetMapping("/request-param-test")
	public String requestParamTest() {
		log.info("@RequestParam train 페이지 요청");
		return "request-param-test";
	}
	
	
	/*
	 * 1. 필수 파라미터 
	 * URL 예시: /books/search?keyword=자바
	 * 
	 * @param keyword 검색 키워드 (필수 파라미터)
	 * @param model 뷰에 데이터 전달용 Model 객체
	 * @return JSP 뷰 이름 
	 */
	@GetMapping("/books/search")
	public String searchBooks(
			@RequestParam("keyword") String keyword, Model model) {
		log.info("도서 검색 요청 - 키워드: {}", keyword);
		
		//서비스를 통해 도서 검색
		List<Book> books = bookService.searchBooks(keyword, null);
		
		//Model에 데이터 추가 (JSP에서 사용)
		model.addAttribute("books", books);
		model.addAttribute("keyword", keyword);
		model.addAttribute("resultCount", books.size());
		model.addAttribute("searchType", "basic");		// 검색 타입 구분
		
		return "request-param-test";		// 같은 페이지로 돌아가서 결과 표시
	}
}
















