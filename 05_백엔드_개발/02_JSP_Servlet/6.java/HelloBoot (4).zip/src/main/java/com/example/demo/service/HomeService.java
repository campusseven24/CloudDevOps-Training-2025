package com.example.demo.service;

import com.example.demo.entity.Member;

import java.util.List;

public interface HomeService {
    public List<Member> memberList();
}
