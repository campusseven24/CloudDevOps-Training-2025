package com.example.demo.repository;

import com.example.demo.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/*
    Repository 인터페이스 선언
        - 인터페이스만 정의하면 Spring Data JPA가 구현체를 자동 생성
        - @Repository 어노테이션 불필요 (JpaRepository 상속으로 자동 인식)
        - JpaRepository<엔터티타입, ID타입> 형식으로 제네릭 지정
 */

public interface HomeRepository extends JpaRepository<Member, Long> {

    //JpaRepository가 기본 제공하는 메소드들
    /*
        저장관련 : save()
                  saveAll()
                  flush()
        조회관련 : findById()
                  findAll()
                  findAllById()
                  count()
        삭제관련 : deleteById()
                  delete()
                  deleteAll()
        페이징 및 정렬 : findAll(Sort sort)
     */
}

















