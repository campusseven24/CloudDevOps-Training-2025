package com.library.dto;

public class MemberResponseDTO {
}
