package com.example.restful.restcontroller;

import com.example.restful.entity.Book;
import com.example.restful.entity.BookPayloadDTO;
import com.example.restful.entity.BookViewDTO;
import com.example.restful.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@RestController     // RESTFul 웹 서비스 컨트롤러 (@Controller + @ResponseBody)
@RequestMapping("/api")     // 기본 URL 경로
@Tag(name = "Book Controller", description = "책을 관리하는 컨트롤러")  //Swagger 문서화
public class BookRestController {

    private final BookService bookService;

    // 생성자 주입
    public BookRestController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/test")
    @Tag(name = "User API")
    @Operation(summary = "User 조회", description = "User 정보를 조회합니다.")
    public String test() {
        return "Hello World!";      // JSON 형태로 응답
    }

    // 책 등록 API
    @PostMapping(value = "/books", consumes = "application/json",
                                        produces = "application/json")
    @ApiResponse(responseCode = "200", description = "Book added")
    @ApiResponse(responseCode = "400", description = "Please add valid name")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Add an Book") // Swagger 문서화용
    public ResponseEntity<BookViewDTO>
            addBook(@Valid @RequestBody BookPayloadDTO bookPayloadDTO) {
        // @RequestBody: HTTP 요청 본문의 JSON을 BookPayloadDTO 객체로 자동 변환
        try {
            // DTO를 엔터티로 변환 (클라이언트 데이터 => DB 저장용 객체)
            Book book = new Book();     //새 Book 엔터티 생성
            book.setSubject(bookPayloadDTO.getSubject());
            book.setPrice(bookPayloadDTO.getPrice());
            book.setAuthor(bookPayloadDTO.getAuthor());
            book.setPage(bookPayloadDTO.getPage());
            // 데이터베이스 저장
            book = bookService.save(book);

            // 엔터티를 응답 DTO로 변환 (DB 데이터 => 클라이언트 응답용 객체)
            BookViewDTO bookViewDTO = new BookViewDTO(
                    book.getId(),           //자동 생성된 ID
                    book.getSubject(),
                    book.getPrice(),
                    book.getAuthor(),
                    book.getPage(),
                    book.getCreatedAt()     //생성 시간
            );
            return ResponseEntity.ok(bookViewDTO);      // HTTP 200 OK 상태코드와 함께
                                                        // bookViewDTO를 JSON으로 변환
        } catch (Exception e) {
            e.printStackTrace();   //(디버깅용)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }                               // 응답 본문없이 상태코드만 반환
    }

    // ======전체 책 목록 조회 API=====
    @GetMapping(value = "/books", produces = "application/json")
    @ApiResponse(responseCode = "200", description = "List of books")
    @Operation(summary = "List book API")
    public List<BookViewDTO> books() {
        // Spring이 자동으로 JSON 배열로 변환
        List<BookViewDTO> books = new ArrayList<>();
        for(Book book : bookService.findAll()) {
            //Entity -> DTO 변환 (Entity 직접 반환 안함-불필요한 정보 노출, DB구조 노출)
            books.add(new BookViewDTO(
                    book.getId(),
                    book.getSubject(),
                    book.getPrice(),
                    book.getAuthor(),
                    book.getPage(),
                    book.getCreatedAt()
            ));
        }
        return books;       //JSON 배열로 자동 변환되어 반환
    }


    // ======특정 책 조회 API=====
    @GetMapping(value = "/books/{id}", produces = "application/json")
    @ApiResponse(responseCode = "200", description = "id에 해당하는 책정보를 출력")
    @Operation(summary = "book id API")
    public ResponseEntity<?> findById(@PathVariable Long id) {
        Optional<Book> optionalBook = bookService.findById(id);
        Book book;

        if (optionalBook.isPresent()) {
            book = optionalBook.get();
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        // DTO로 변환하여 반환
        BookViewDTO bookViewDTO = new BookViewDTO(
               book.getId(),
               book.getSubject(),
               book.getPrice(),
               book.getAuthor(),
               book.getPage(),
               book.getCreatedAt()
        );
        return ResponseEntity.ok(bookViewDTO);
            // HTTP 200 OK + bookViewDTO를 JSON으로 변환하여 응답.
    }


    // ======특정 책 수정 API=====
    @PutMapping(value = "/books/{id}", consumes = "application/json",
            produces = "application/json")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiResponse(responseCode = "204", description = "Book Update")
    @ApiResponse(responseCode = "404", description = "Not Found")
    @Operation(summary = "Update a Book")
    public ResponseEntity<?> updateBook(@Valid @RequestBody BookPayloadDTO payloadDTO,
                                        @PathVariable Long id) {
        // @RequestBody : 요청 본문의 JSON을 BookPayloadDTO로 자동 변환

        // 수정할 책 조회
        Optional<Book> optionalBook = bookService.findById(id);
        // DB에서 해당 ID의 책 조회 (select * from where id = ?)

        Book book;      // 수정할 Book 엔터티를 담을 변수
        if (optionalBook.isPresent()) {
            book = optionalBook.get();      //실제 Book 객체 추출
        } else {
            //책이 존재하지 않는 경우
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        // 수정 데이터 적용 (기존 엔터티의 필드값 변경)
        book.setSubject(payloadDTO.getSubject());       //제목 수정
        book.setPrice(payloadDTO.getPrice());           //가격 수정
        book.setAuthor(payloadDTO.getAuthor());         //저자 수정
        book.setPage(payloadDTO.getPage());             //페이지 수정
        //id와 createdAt은 수정하지 않음(보전되어야 할 값)

        //저장 (JPA는 수정시 save 메소드 사용)
        book = bookService.save(book);

        // Entity => DTO 변환하여 응답 준비
        BookViewDTO bookViewDTO = new BookViewDTO(
                book.getId(),           //ID 변경 없음
                book.getSubject(),      //수정된 제목
                book.getPrice(),        //수정된 가격
                book.getAuthor(),       //수정된 저자
                book.getPage(),         //수정된 페이지
                book.getCreatedAt()     // 생성일 변경 안됨
        );

        return ResponseEntity.ok(bookViewDTO);
                // HTTP 200 OK + 수정된 책 정보를 JSON으로 응답
    }

    // === 책 삭제 API ===
    @DeleteMapping("/books/{id}")   // {id}: 삭제할 책의 ID를 URL에서 받음
    @Operation(summary = "Delete a Book")
    public ResponseEntity<?> deleteBook(@PathVariable Long id) {
        // DB에서 삭제할 책 조회 (SELECT * FROM book WHERE id = ?) //삭제전 존재 여부 확인
        Optional<Book> optionalBook = bookService.findById(id);
        Book book;      // 삭제할 Book 엔터티를 담을 변수
        if (optionalBook.isPresent()) { // 책이 존재하는 경우
            book = optionalBook.get();  // Optional에서 실제 Book 객체 추출
        } else {    // 책이 존재하지 않는 경우
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        bookService.delete(book);       // 데이터베이스에서 삭제 DELETE FROM book WHERE id = ? 실행

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(null); //202
    }


    // === 이미지 업로드 API ===
    @PostMapping(value = "/{book_id}/{type}/upload", consumes = {"multipart/form-data"})
    public ResponseEntity<?> imagesUpload(
            //@RequestPart : multipart요청의 특정 파트를 받음. MultipartFile[]: 여러 파일 동시 업로드 가능
            @RequestPart(required = true) MultipartFile[] files,
            @PathVariable Long book_id,   // 책 ID, {book_id} 추출 // /api/5/1/upload
            @PathVariable int type) {     // 이미지 타입 (1:썸네일, 2: 일반 등)

        // 책 존재 여부 확인 (SELECT * FROM book WHERE id = ?)
        Optional<Book> optionalBook = bookService.findById(book_id);
        Book book;      // 조회된 Book 엔터티를 담을 변수

        if(optionalBook.isPresent()) {
            book = optionalBook.get();
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        // 성공/실패 파일명 저장 리스트
        List<String> successImageName = new ArrayList<>();  // 업로드 성공한 파일명들을 저장
        List<String> errorImageName = new ArrayList<>();  // 업로드 실패한 파일명들을 저장

        // 각 파일 처리
        Arrays.asList(files).stream().forEach(file -> {
            String contentType = file.getContentType(); //파일의 MIME 타입 가져오기 ("image/png, image/jpeg")

            //이미지 파일 형식 검증
            if (contentType.equals("image/png") ||
                contentType.equals(("image/jpg")) ||
                contentType.equals(("image/jpeg"))) {
                // 정상적인 경우 원본 파일명 저장
                successImageName.add(file.getOriginalFilename());

                //
            }
        });


        return ResponseEntity.ok(null);
    }


}


















