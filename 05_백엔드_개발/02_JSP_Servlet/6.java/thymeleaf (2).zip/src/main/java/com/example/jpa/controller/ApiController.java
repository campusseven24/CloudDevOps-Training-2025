package com.example.jpa.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Slf4j              // Lombok 로깅 기능 자동 추가 (log변수 사용 가능)
@RestController     // @Controller + @ResponseBody => 모든 메서드가 JSON 반환
@RequestMapping("/api")    // 기본 경로 매핑, 애플리케이션 루트 url /api 시작
public class ApiController {

    /*
        JSON 객체 응답
            - Map을 사용한 JSON 데이터 반환
            - Spring이 자동으로 Map => JSON 변환
     */
    @GetMapping("/info")
    public Map<String, Object> getInfo() {
        log.info("GET /api/info 호출함");

        Map<String, Object> info = new HashMap<>();
        info.put("application", "Asyn Test");
        info.put("version", "1.0.0");
        info.put("timestamp", LocalDateTime.now());
        info.put("status", "running");

        return info; // {"application": "Asyn Test", ...}
    }
}
