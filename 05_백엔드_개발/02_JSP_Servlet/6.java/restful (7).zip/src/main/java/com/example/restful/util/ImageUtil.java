package com.example.restful.util;

import org.imgscalr.Scalr;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

// 이미지 처리 관련 유틸리티 클래스  (static 메소드들로 구성)
public class ImageUtil {

    // 단일 이미지 삭제                    기본 업로드 경로     책ID (풀더명)   삭제할 파일명
    public static boolean deleteImage(String uploadPath, Long book_id, String fileName) {
        try {
            //삭제할 파일의 절대 경로 생성
            // uploadPath + "\\" + book_id + "\\" + fileName
            File file = new File(uploadPath + "\\" + book_id + "\\" + fileName);

            if (file.delete()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    // 업로드 경로 생성 메소드
    public static String makePath(String uploadPath, String fileName, Long book_id) throws IOException {
        // /uploads/5/ -- 각 책마다 별도 폴더로 이미지 처리
        String path = uploadPath +"\\"+ book_id;
        System.out.println("========================" + path);

        //중간 경로 포함 모든 디렉토리 생성
        Files.createDirectories(Paths.get(path));

        return new File(path).getAbsolutePath() +"\\"+ fileName;
    }

    // 썸네일 생성 메소드
    // 리사이징된 BufferedImage 객체 (반환타입)                          //썸네일 목표 너비 (픽셀)
    public static BufferedImage getThumbnail(MultipartFile originFile, Integer width) throws IOException {
        BufferedImage thumbImg = null;      // 썸네일 이미지를 담을 변수
        BufferedImage img = ImageIO.read(originFile.getInputStream());  // 원본 이미지 읽기
        thumbImg = Scalr.resize(img,
                Scalr.Method.AUTOMATIC, // 리사이징 알고리즘 최적 알고리즘 자동 선택
                Scalr.Mode.AUTOMATIC, // 가로/세로 비율 자동 결정
                width,  // 비율에 맞춰 자동 계산됨
                Scalr.OP_ANTIALIAS);  // 계단 현상 제거로 부드러운 이미지 생성
        return thumbImg;            // 메모리상의 이미지이므로 별도 파일로 저장 필요
    }
}
