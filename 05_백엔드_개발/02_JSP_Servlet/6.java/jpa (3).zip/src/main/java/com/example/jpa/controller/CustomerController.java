package com.example.jpa.controller;

import com.example.jpa.entity.Customer;
import com.example.jpa.service.CustomerService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller     // Spring MVC 컨트롤러, View를 반환 (@RestController와 구분됨)
@RequestMapping("/customer")    // 기본 URL 경로 설정, 모든 메서드는 /customer로 시작
@AllArgsConstructor     // 생성자 주입을 위한 Lombok 어노테이션
public class CustomerController {

    private final CustomerService customerService;  // 서비스 계층 의존성 주입 (DI)

    @GetMapping("/register")
    public String register() {
        // 폼에서 받아야 하지만, 테스트용으로 하드코딩
        Customer customer = new Customer();
        customer.setUsername("springAI");
        customer.setPassword("12345");
        customer.setAge(30);
        customer.setCustomerName("이순신");
        customer.setRating("GOLD");
        customer.setOccupation("회사원");

        Customer cus = customerService.register(customer);  // DB 저장
        return "redirect:/";        //메인 페이지로 리다이렉트 (URL 변경)
    }
}











