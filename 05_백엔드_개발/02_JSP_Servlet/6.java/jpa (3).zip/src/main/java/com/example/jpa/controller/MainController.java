package com.example.jpa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller     // HTML View 반환
@RequestMapping("/")    // 기본 경로 매핑, 애플리케이션 루트 URL
public class MainController {

    // URL : GET http://localhost:8081/
    @GetMapping
    public String index(Model model) {
        return "index";
    }
}
