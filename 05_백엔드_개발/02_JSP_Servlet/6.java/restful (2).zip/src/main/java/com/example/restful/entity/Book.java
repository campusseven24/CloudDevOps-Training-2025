package com.example.restful.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity     // JPA 엔터티임 선언 (데이터베이스 테이블과 매핑)
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    @Id //기본키 (PK) 지정
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // 자동 증가 전략 (auto_increment)
    private Long id;
    private String subject;
    private int price;
    private String author;
    private int page;
    private LocalDateTime createdAt;
}
