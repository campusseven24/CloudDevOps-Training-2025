package com.example.jpa.repository;


import com.example.jpa.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // 1) JpaRepository가 제공하는 기본 메시드들 : save(), findById(), deleteById(), count()..

    //2) 쿼리 메서드
    /*
        단순 조건 검색-username으로 고객 검색
        findBy = SELECT 쿼리
        Username = WHERE username 조건
        파라미터 (String username) = 조건 값

        => SELECT * FROM customer
           WHERE username = ?
     */
    Optional<Customer> findByUsername(String username);

    /*
        And 조건 검색
        - 로그인 체크
        - username과 password로 로그인 체크
     */
    Optional<Customer> findByUsernameAndPassword(String username, String password);

}
