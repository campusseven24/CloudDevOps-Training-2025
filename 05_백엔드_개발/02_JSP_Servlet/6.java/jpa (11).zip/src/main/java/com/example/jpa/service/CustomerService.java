package com.example.jpa.service;

import com.example.jpa.entity.Customer;
import com.example.jpa.repository.CustomerRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service    // Service Bean으로 등록, 비지니스 로직 처리 계층
@AllArgsConstructor // 모든 필드를 파라미터로 받는 생성자 자동 생성 (DI용)
public class CustomerService {
    private final CustomerRepository customerRepository;    //생성자 주입

    //회원 등록
    @Transactional  // insert, update, delete 메서드 실행중 예외 발생시 자동 롤백
    public Customer register(Customer customer) {
        return customerRepository.save(customer);   // save() -> insert SQL
    }

    //특정회원 한명의 정보 가져오기
    @Transactional(readOnly = true)  // 읽기 전용, 성능 최적화
    public Optional<Customer> getById(Long id) {    // PK(id)
        return customerRepository.findById(id);     // SELECT * FROM customer WHERE id = ?
    }

    //회원목록 가져오기
    @Transactional(readOnly = true)
    public List<Customer> getAllCustomer() {

        List<Customer> allCustomers = customerRepository.findAll(); // SELECT SQL~

        //삭제되지 않은 회원만 필터링 (deletedAt = false인 회원만)
        return  allCustomers.stream()
                .filter(customer -> !customer.isDeleted())  //deleted가 false인 것만
                .toList();
    }

    /*
    회원 수정
        - save() 메서드는 ID가 있으면 Update, 없으면 Insert
     */
    public Customer update(Customer customer) {
        // 기존 회원 정보 조회
        Customer existingCustomer =
        customerRepository.findById(customer.getId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "회원을 찾을 수 없습니다. ID: " + customer.getId()
                ));
        // 수정 가능한 필드만 업데이트 (username은 변경 불가능하므로 제외)
        existingCustomer.setCustomerName(customer.getCustomerName());
        existingCustomer.setAge(customer.getAge());
        existingCustomer.setOccupation(customer.getOccupation());
        existingCustomer.setRating(customer.getRating());
        existingCustomer.setReserves(customer.getReserves());

        // 변경된 엔터티 저장
        return customerRepository.save(existingCustomer);
    }

    public void softDelete(Long id) {
        // 삭제할 회원 조회
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "회원을 찾을 수 없습니다. ID: " + id
                ));
        // 이미 삭제된 회원인지 확인
        if (customer.isDeleted()) {
            throw new IllegalStateException("이미 삭제된 회원입니다.");
        }

        // 삭제 플래그 설정
        customer.setDeleted(true);          // 삭제 상태로 변경
        customer.setDeletedAt(new Date());  // 삭제 시간 기록

        // 변경사항 저장 (UPDATE SQL 실행)
        customerRepository.save(customer);

    }

    // 쿼리 메서드 테스트
    @Transactional(readOnly = true)
    public void testQueryMethods() {
        Optional<Customer> user = customerRepository.findByUsername("choongang");
        System.out.println("choongang 사용자 조회");
        user.ifPresent(c -> System.out.println(" -> " + c.getCustomerName()));
    }

    // 쿼리 메서드 테스트- 로그인 체크
    @Transactional(readOnly = true)
    public void test2FindByUsernameAndPassword() {
        System.out.println("\n [test2] test2FindByUsernameAndPassword");
        System.out.println("==========================================");

        Optional<Customer> loginUser =
        customerRepository.findByUsernameAndPassword("choongang", "12");

        System.out.println(" * 테스트 계정: choongang / 12");
        System.out.println(" * 테스트 결과: " + (loginUser.isPresent() ? "✅성공" : "❌ 실패"));

        if (loginUser.isPresent()) {
            System.out.println(" * 로그인 사용자: " + loginUser.get().getCustomerName());
        }
    System.out.println("\n 생성된 SQL : SELECT * FROM customer WHERE username = ? AND password = ?");
    }
}
