package com.example.restful.restcontroller;

import com.example.restful.entity.Book;
import com.example.restful.entity.BookPayloadDTO;
import com.example.restful.entity.BookViewDTO;
import com.example.restful.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController     // RESTFul 웹 서비스 컨트롤러 (@Controller + @ResponseBody)
@RequestMapping("/api")     // 기본 URL 경로
@Tag(name = "Book Controller", description = "책을 관리하는 컨트롤러")  //Swagger 문서화
public class BookRestController {

    private final BookService bookService;

    // 생성자 주입
    public BookRestController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/test")
    @Tag(name = "User API")
    @Operation(summary = "User 조회", description = "User 정보를 조회합니다.")
    public String test() {
        return "Hello World!";      // JSON 형태로 응답
    }

    // 책 등록 API
    @PostMapping(value = "/books", consumes = "application/json",
                                        produces = "application/json")
    @ApiResponse(responseCode = "200", description = "Book added")
    @ApiResponse(responseCode = "400", description = "Please add valid name")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Add an Book") // Swagger 문서화용
    public ResponseEntity<BookViewDTO>
            addBook(@Valid @RequestBody BookPayloadDTO bookPayloadDTO) {
        // @RequestBody: HTTP 요청 본문의 JSON을 BookPayloadDTO 객체로 자동 변환
        try {
            // DTO를 엔터티로 변환 (클라이언트 데이터 => DB 저장용 객체)
            Book book = new Book();     //새 Book 엔터티 생성
            book.setSubject(bookPayloadDTO.getSubject());
            book.setPrice(bookPayloadDTO.getPrice());
            book.setAuthor(bookPayloadDTO.getAuthor());
            book.setPage(bookPayloadDTO.getPage());
            // 데이터베이스 저장
            book = bookService.save(book);

            // 엔터티를 응답 DTO로 변환 (DB 데이터 => 클라이언트 응답용 객체)
            BookViewDTO bookViewDTO = new BookViewDTO(
                    book.getId(),           //자동 생성된 ID
                    book.getSubject(),
                    book.getPrice(),
                    book.getAuthor(),
                    book.getPage(),
                    book.getCreatedAt()     //생성 시간
            );
            return ResponseEntity.ok(bookViewDTO);      // HTTP 200 OK 상태코드와 함께
                                                        // bookViewDTO를 JSON으로 변환
        } catch (Exception e) {
            e.printStackTrace();   //(디버깅용)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }                               // 응답 본문없이 상태코드만 반환
    }

    // ======전체 책 목록 조회 API=====
    @GetMapping(value = "/books", produces = "application/json")
    @ApiResponse(responseCode = "200", description = "List of books")
    @Operation(summary = "List book API")
    public List<BookViewDTO> books() {
        // Spring이 자동으로 JSON 배열로 변환
        List<BookViewDTO> books = new ArrayList<>();
        for(Book book : bookService.findAll()) {
            //Entity -> DTO 변환 (Entity 직접 반환 안함-불필요한 정보 노출, DB구조 노출)
            books.add(new BookViewDTO(
                    book.getId(),
                    book.getSubject(),
                    book.getPrice(),
                    book.getAuthor(),
                    book.getPage(),
                    book.getCreatedAt()
            ));
        }
        return books;       //JSON 배열로 자동 변환되어 반환
    }


    // ======특정 책 조회 API=====
    @GetMapping(value = "/books/{id}", produces = "application/json")
    @ApiResponse(responseCode = "200", description = "id에 해당하는 책정보를 출력")
    @Operation(summary = "book id API")
    public ResponseEntity<?> findById(@PathVariable Long id) {
        Optional<Book> optionalBook = bookService.findById(id);
        Book book;

        if (optionalBook.isPresent()) {
            book = optionalBook.get();
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        // DTO로 변환하여 반환
        BookViewDTO bookViewDTO = new BookViewDTO(
               book.getId(),
               book.getSubject(),
               book.getPrice(),
               book.getAuthor(),
               book.getPage(),
               book.getCreatedAt()
        );
        return ResponseEntity.ok(bookViewDTO);
            // HTTP 200 OK + bookViewDTO를 JSON으로 변환하여 응답.
    }

}


















