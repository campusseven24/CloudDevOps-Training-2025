package com.initializr.springstarter.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity  // JPA 엔터티 클래스 명시 - 데이터베이스 테이블과 매핑됨
@Getter
@Setter
@NoArgsConstructor
public class Book {
    @Id       // 해당 필드가 Primary Key임을 명시
    @GeneratedValue(strategy = GenerationType.IDENTITY) //기본키 생성 전략 : 자동 증가
    private Long id;            // 책의 고유 식별자
    private String subject;     // 책 제목
    private int price;          // 책 가격
    private String author;      // 저자명
    private int page;           // 페이지 수
    private LocalDateTime createdAt;    // 출 정보 생성 시간
}
