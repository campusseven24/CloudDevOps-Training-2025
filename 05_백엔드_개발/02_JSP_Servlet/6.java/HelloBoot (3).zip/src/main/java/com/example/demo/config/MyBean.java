package com.example.demo.config;

// 일반적인 자바 클래스 (POJO: Plain Old Java Object)
public class MyBean {
    public MyBean() {
        System.out.println("MyBean()");
    }

}
