package com.example.filterinterceptor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilterinterceptorApplicationTests {

	@Test
	void contextLoads() {
	}

}
