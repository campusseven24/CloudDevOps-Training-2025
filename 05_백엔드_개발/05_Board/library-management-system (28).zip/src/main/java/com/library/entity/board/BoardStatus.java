package com.library.entity.board;

public enum BoardStatus {
    ACTIVE,     //활성
    DELETED,    //삭제됨
    HIDDEN      //숨김
}

