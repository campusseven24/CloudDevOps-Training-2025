package com.library.entity.board;

/*
    댓글 상태 staus
 */
public enum CommentStatus {
    ACTIVE,     // 활성 (정상적으로 보임)
    DELETED     // 삭제됨 (소프트 삭제)
}
