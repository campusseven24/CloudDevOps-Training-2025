package com.example.boardservice.service;

import com.example.boardservice.client.UserClient;
import com.example.boardservice.domain.Board;
import com.example.boardservice.domain.BoardRepository;
import com.example.boardservice.dto.BoardResponseDto;
import com.example.boardservice.dto.CreateBoardRequestDto;
import com.example.boardservice.dto.UserDto;
import com.example.boardservice.dto.UserResponseDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class BoardService {
    private final BoardRepository boardRepository;
    private final UserClient userClient;

    public BoardService(BoardRepository boardRepository, UserClient userClient) {
        this.boardRepository = boardRepository;
        this.userClient = userClient;
    }

    @Transactional      // 메서드 실행 중 예외 발생 시 롤백, 성공 시 커밋
    public void create(CreateBoardRequestDto createBoardRequestDto) {
        Board board = new Board(    // Board 엔티티 객체 생성 (DTO 데이터를 도메인 모델로 변환)
                createBoardRequestDto.getTitle(),       // DTO에서 제목 추출
                createBoardRequestDto.getContent(),     // DTO에서 내용 추출
                createBoardRequestDto.getUserId()       // DTO에서 작성자 ID 추출
        );
        this.boardRepository.save(board);   // JPA를 통해 DB에 게시글 저장 (INSERT 쿼리 실행)
    }

    public BoardResponseDto getBoard(Long boardId) { // 게시글 + 사용자 정보 통합 데이터 반환
        // board-service의 DB에서 게시글 조회
        Board board = boardRepository.findById(boardId)     // DB에서 ID로 게시글 조회 (SELECT 쿼리 실행)
                .orElseThrow(() -> new IllegalArgumentException("게시글을 찾을 수 없습니다.")); //조회 결과 없으면 예외 발생

        // user-service로부터 사용자 정보 불러오기 (MSA간 HTTP 통신)
        // UserClient를 통해 간결하게 호출
        Optional<UserResponseDto> optionalUserResponseDto = userClient.fetchUser(board.getUserId());

        UserDto userDto = null;
        // 응답값 조합하기 (두 서비스의 데이터를 하나의 DTO로 통합)
        // UserDto 생성
        if (optionalUserResponseDto.isPresent()) {
            UserResponseDto userResponseDto = optionalUserResponseDto.get();      // 실제 값을 꺼내옴
            userDto = new UserDto(
                    userResponseDto.getUserId(),    // 사용자 ID
                    userResponseDto.getName()       // 사용자 이름
            );
        }


        // BoardResponseDto 생성
        BoardResponseDto boardResponseDto = new BoardResponseDto(
                board.getBoardId(),     //게시글 ID
                board.getTitle(),       //게시글 제목
                board.getContent(),     // 게시글 내용
                userDto // 작성자 정보 (user-service로부터 조회한 데이터)
        );

        return boardResponseDto;    //통합된 응답 DTO (응답 조합)
    }

    // 게시글 전체 조회  (N+1 문제 해결 패턴 적용)
    /*
        비즈니스 로직 수행
        N+1 문제 해결 (일괄 조회)
        user-service 통신 (UserClient 사용)
        데이터 통합 및 DTO 변환

        * stream.map(b -> b.getUserId());  //람다식
          stream.map(Board::getUserId)     //메서드 레퍼런스
     */
    public List<BoardResponseDto> getBoards() {  // 모든 게시글 + 작성자 정보 통합 리스트
        // 1. board-service DB에서 모든 게시글 조회
        List<Board> boards = boardRepository.findAll();  // SELECT * FROM boards (모든 게시글 일괄 조회)

        //2. 게시글에서 고유한 userId 목록 추출 (N+1 문제 방지하기 위한 준비)
        List<Long> userIds = boards.stream()     // Stream API로 변환 시작
                .map(Board::getUserId)   // 각 Board에서 userId만 추출 (Board->Long변환)
                .distinct() // 중복 제거 (동일 작성자의 게시글이 여러 개일 수 있으므로)
                .toList();

        //3. user-service로부터 모든 사용자 정보 일괄 조회 (1번의 HTTP 호출)
        // 핵심: N + 1 문제 해결 -- 게시글마다 개별 호출(N번) 대신 일괄 호출 (1번)
        List<UserResponseDto> userResponseDtos = userClient.fetchUsersByIds(userIds);

        //4. 빠른 조회를 위한 Map 생성 (userId를 Key로 하는 인덱스)
        Map<Long, UserDto> userMap = new HashMap<>();   // userId => UserDTO 매핑
        for (UserResponseDto userResponseDto : userResponseDtos) { // user-service에서 받은 사용자 리스트 조회
            Long userId = userResponseDto.getUserId();        // 사용자 ID 추출
            String name = userResponseDto.getName();          // 사용자 이름 추출
            userMap.put(userId, new UserDto(userId, name));   // Map에 userId를 Key로 저장
        }

        //5. 게시글과 사용자 정보를 조합하여 최종 응답 DTO 생성
        return boards.stream()  // 게시글 리스트를 Stream으로 변환
                .map(board -> new BoardResponseDto( //각 Board를 BoardResponseDto로 변환
                        board.getBoardId(), // 게시글 ID
                        board.getTitle(),   // 게시글 제목
                        board.getContent(), // 게시글 내용
                        userMap.get(board.getUserId()) //Map에서 userId로 UserDto 빠르게 조회
                ))
                .toList();  // Stream 결과를 List<UserResponseDto>로 수집하여 변환

    }
}



















