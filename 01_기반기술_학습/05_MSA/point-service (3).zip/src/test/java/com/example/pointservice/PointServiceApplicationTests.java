package com.example.pointservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
