package com.example.pointservice.domain;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/*
    Spring Data JPA가 런타임에 자동으로 구현체를 생성하여 제공
        - save(Point), findById(Long), findAll(), deleteById(Long), count()등등
 */
public interface PointRepository extends JpaRepository<Point, Long> {
    // 사용자 ID로 포인트 조회 (쿼리 메서드)
    Optional<Point> findByUserId(Long userId);
}
