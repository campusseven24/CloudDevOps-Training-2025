package com.example.pointservice.service;

import com.example.pointservice.domain.Point;
import com.example.pointservice.domain.PointRepository;
import com.example.pointservice.dto.AddPointRequestDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PointService {
    private final PointRepository pointRepository;

    // 생성자 기반 의존성 주입
    public PointService(PointRepository pointRepository) {
        this.pointRepository = pointRepository;
    }

    // 포인트 적립 비즈니스 로직
    /*
        1) 사용자의 기존 포인트 조회
        2) 없으면 새로운 Point 객체 생성 (초기 잔액 0)
        3) 적립 금액 추가
        4) 변경사항을 DB에 저장
     */
    @Transactional
    public void addPoints(AddPointRequestDto addPointRequestDto) {
        //기존 포인트 조회 또는 신규 생성
        Point point = pointRepository.findByUserId(addPointRequestDto.getUserId())
                .orElseGet(() -> new Point(addPointRequestDto.getUserId(), 0));
        point.addAmount(addPointRequestDto.getAmount());
        pointRepository.save(point);
    }

    // 
}
