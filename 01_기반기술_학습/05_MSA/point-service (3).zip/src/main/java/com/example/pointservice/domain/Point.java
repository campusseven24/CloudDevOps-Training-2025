package com.example.pointservice.domain;

import jakarta.persistence.*;

@Entity     // 사용자 포인트 정보를 관리하는 JPA 엔티티 클래스
@Table(name = "points")
public class Point {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pointId;
    private Long userId;    // 사용자 식별자 (user-service의 userId와 연관, FK는 아님)
    private int amount;     // 포인트 잔액

    public Point() {        // JPA 요구사항 : 엔티티는 기본 생성자 필수 (DB 조회 시)
    }

    public Point(Long userId, int amount) {  // 포인트 생성 시 사용하는 생성자
        this.userId = userId;
        this.amount = amount;
    }

    public Long getPointId() {
        return pointId;
    }

    public Long getUserId() {
        return userId;
    }

    public int getAmount() {
        return amount;
    }

    // 비즈니스 로직 - 포인트 적립 메서드
    public void addAmount(int amount) {
        this.amount += amount;      // 현재 잔액에 적립 금액 추가
    }

    // 포인트 차감 메서드
    public void deductAmount(int amount) {
        this.amount -= amount;      // 현재 잔액에서 사용 금액 차감
    }


}
