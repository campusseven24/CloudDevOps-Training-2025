package com.example.pointservice.dto;

// 포인트 적립 요청 데이터 전송 객체
/*
    역할
        - HTTP 요청 본문(JSON)과 자바 객체간의 데이터 전송
        - Controller에서 @RequestBody로 받는 요청 데이터 구조 정의
 */
public class AddPointRequestDto {
    private Long userId;        // 포인트를 적립할 사용자 ID
    private int amount;         // 적립할 포인트 금액 (양수)

    public AddPointRequestDto() {
    }

    public Long getUserId() {
        return userId;
    }

    public int getAmount() {
        return amount;
    }
}
