package com.example.boardservice.client;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component          // Spring 빈으로 등록하여 의존성 주입 가능하게 함
public class UserClient {
    private final RestClient restClient;  // Spring 6.1+에서 도입된 최신 HTTP 클라이언트

    public UserClient(@Value("${client.user-service.url}") String userServiceUrl) {
        this.restClient = RestClient.builder()
                .baseUrl(userServiceUrl)
                .build();   // RestClient 인스턴스 생성
    }
}

