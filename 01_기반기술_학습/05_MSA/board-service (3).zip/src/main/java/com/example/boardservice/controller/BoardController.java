package com.example.boardservice.controller;

import com.example.boardservice.dto.CreateBoardRequestDto;
import com.example.boardservice.service.BoardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/boards")
public class BoardController {
    private final BoardService boardService;

    public BoardController(BoardService boardService) {
        this.boardService = boardService;
    }

    @PostMapping    // POST /boards
    public ResponseEntity<Void> create(     // 응답 본문(Body)이 없음, 상태코드만 반환
            @RequestBody CreateBoardRequestDto createBoardRequestDto  // 요청 본문을 DTO로 바인딩
    ){
        boardService.create(createBoardRequestDto);  // 게시글 생성 로직 호출
        return ResponseEntity.noContent().build(); // 204 No Content
    }
}
















