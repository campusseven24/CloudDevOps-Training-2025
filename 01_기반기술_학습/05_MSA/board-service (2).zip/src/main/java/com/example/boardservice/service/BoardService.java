package com.example.boardservice.service;

import com.example.boardservice.domain.Board;
import com.example.boardservice.domain.BoardRepository;
import com.example.boardservice.dto.CreateBoardRequestDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BoardService {
    private final BoardRepository boardRepository;

    public BoardService(BoardRepository boardRepository) {
        this.boardRepository = boardRepository;
    }

    @Transactional      // 메서드 실행 중 예외 발생 시 롤백, 성공 시 커밋
    public void create(CreateBoardRequestDto createBoardRequestDto) {
        Board board = new Board(    // Board 엔티티 객체 생성 (DTO 데이터를 도메인 모델로 변환)
                createBoardRequestDto.getTitle(),       // DTO에서 제목 추출
                createBoardRequestDto.getContent(),     // DTO에서 내용 추출
                createBoardRequestDto.getUserId()       // DTO에서 작성자 ID 추출
        );
        this.boardRepository.save(board);   // JPA를 통해 DB에 게시글 저장 (INSERT 쿼리 실행)
    }
}
