package com.example.boardservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
