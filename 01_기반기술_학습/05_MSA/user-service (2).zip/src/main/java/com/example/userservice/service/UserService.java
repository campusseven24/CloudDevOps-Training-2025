package com.example.userservice.service;

import com.example.userservice.domain.User;
import com.example.userservice.domain.UserRepository;
import com.example.userservice.dto.SignUpRequestDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
    private final UserRepository userRepository;


    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Transactional
    public void signUp(SignUpRequestDto signUpRequestDto) { // DB 저장만 수행
        User user = new User(       // User 엔티티 객체 생성 (DTO 데이터를 도메인 모델로 변환)
                signUpRequestDto.getEmail(),    // DTO에서 이메일 추출
                signUpRequestDto.getName(),     // DTO에서 이름 추출
                signUpRequestDto.getPassword()  // DTO에서 비밀번호 추출
        );

        this.userRepository.save(user);   // JPA를 통해 DB에 사용자 정보 저장 (Insert 쿼리 실행)
    }
}
















