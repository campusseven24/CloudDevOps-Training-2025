package com.example.userservice.dto;

/*
    user-service에서 point-service로 포인트 적립 API를 호출할 때 사용하는
    요청 DTO
        - MSA 통신 시나리오
            - 1) 회원 가입 시 초기 포인트 1000점 적립
 */
public class AddPointRequestDto {
    private Long userId;
    private int amount;

    public AddPointRequestDto(Long userId, int amount) {
        this.userId = userId;
        this.amount = amount;
    }

    public Long getUserId() {
        return userId;
    }

    public int getAmount() {
        return amount;
    }
}
