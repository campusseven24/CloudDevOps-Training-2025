package com.example.userservice.client;

import com.example.userservice.dto.AddPointRequestDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

/*
    Point Service 통신 클라이언트
        - user-service에서 point-service로 HTTP 요청을 보내는 클라이언트 클래스
        - MSA 통신 패턴
            - 서비스 간 통신은 HTTP REST API를 통해서만 이루어짐
            - 직접적인 데이터베이스 접근 금지
            - RestClient를 사용한 동기(synchronous) HTTP 통신

        - 시나리오
            - 회원 가입시 초기 포인트 1000점 적립
 */
@Component  // Spring의 빈(bean)으로 등록 --> 의존성 주입(DI)을 통해 사용 가능
public class PointClient {
    private final RestClient restClient;

    public PointClient(
           @Value("${client.point-service.url}") String pointServiceUrl
    ) {
        this.restClient = RestClient.builder()
                .baseUrl(pointServiceUrl)
                .build();
    }

    /*
        point-service에 포인트 적립 요청
     */
    public void addPoints(Long userId, int amount) {
        // 1. DTO 생성
        AddPointRequestDto addPointRequestDto = new AddPointRequestDto(userId, amount);

        // 2. HTTP POST 요청 실행
        this.restClient.post()              // POST 메서드 지정
                .uri("/points/add")     // 엔드포인트 경로
                .contentType(MediaType.APPLICATION_JSON)    // Content-Type 헤더: APPLICATION_JSON
                .body(addPointRequestDto)       // 요청 본문에 DTO를 JSON으로 직렬화하여 전송
                .retrieve()         // 응답받기
                .toBodilessEntity();    // 응답 본문 무시, 상태코드만 확인
    }

    // public void deductPoints(Long userId, int amount) { ... }  //포인트 차감
    // public PointDto getPoints(Long userId) { ... }  // 포인트 조회

}
