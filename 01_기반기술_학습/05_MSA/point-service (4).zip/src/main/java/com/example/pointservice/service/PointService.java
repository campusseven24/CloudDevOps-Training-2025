package com.example.pointservice.service;

import com.example.pointservice.domain.Point;
import com.example.pointservice.domain.PointRepository;
import com.example.pointservice.dto.AddPointRequestDto;
import com.example.pointservice.dto.DeductPointRequestDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PointService {
    private final PointRepository pointRepository;

    // 생성자 기반 의존성 주입
    public PointService(PointRepository pointRepository) {
        this.pointRepository = pointRepository;
    }

    // 포인트 적립 비즈니스 로직
    /*
        1) 사용자의 기존 포인트 조회
        2) 없으면 새로운 Point 객체 생성 (초기 잔액 0)
        3) 적립 금액 추가
        4) 변경사항을 DB에 저장
     */
    @Transactional
    public void addPoints(AddPointRequestDto addPointRequestDto) {
        //기존 포인트 조회 또는 신규 생성
        Point point = pointRepository.findByUserId(addPointRequestDto.getUserId())
                .orElseGet(() -> new Point(addPointRequestDto.getUserId(), 0));
        point.addAmount(addPointRequestDto.getAmount());
        pointRepository.save(point);
    }

    // 포인트 차감 비즈니스 로직
    /*
        처리 흐름
            1) Repository에서 사용자의 포인트 조회 (필수)
            2) 존재하지 않으면 예외 발생 (포인트 없이 차감 불가)
            3) 잔액 부족 검증 (현재 잔액 < 차감 금액 시 예외 발생)
            4) 차감 금액만큼 감소
            5) 변경사항을 DB에 저장
     */
    @Transactional      // 트랜잭션 보장: 메서드 내 모든 DB 작업이 성공하거나 전체 롤백
                        // 예외 발생 시 자동으로 롤백되어 데이터 일관성 유지
    public void deductPoints(DeductPointRequestDto deductPointRequestDto) {
        Point point = pointRepository.findByUserId(deductPointRequestDto.getUserId())
                .orElseThrow(() -> new IllegalArgumentException("사용자의 포인트 정보를 찾을 수 없습니다."));

        // 잔액 부족 검증 (음수 잔액 불가)
        if (point.getAmount() < deductPointRequestDto.getAmount()) {
            throw new IllegalArgumentException(
                    "포인트 잔액이 부족합니다. (현재 잔액: " +point.getAmount()+
                    "포인트, 차감 요청: " +deductPointRequestDto.getAmount()+ "포인트)"
            );
        }

        point.deductAmount(deductPointRequestDto.getAmount());

        pointRepository.save(point);
    }
}











