package com.example.pointservice.dto;

public class DeductPointRequestDto {
    private Long userId;        // 포인트를 차감할 사용자 ID
    private int amount;         // 차감할 포인트 금액 (양수)

    public DeductPointRequestDto() {
    }

    public Long getUserId() {
        return userId;
    }

    public int getAmount() {
        return amount;
    }
}
