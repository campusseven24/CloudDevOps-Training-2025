package com.example.pointservice.controller;

import com.example.pointservice.dto.AddPointRequestDto;
import com.example.pointservice.dto.DeductPointRequestDto;
import com.example.pointservice.service.PointService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController             // @Controller + @ResponseBody
@RequestMapping("/points")  // 기본 url 매핑:  http://localhost:8082/points
public class PointController {
    private final PointService pointService;

    // 생성자 기반 의존성 주입 - Spring이 PointService 빈을 자동으로 주입
    public PointController(PointService pointService) {
        this.pointService = pointService;
    }

    // 포인트 적립 API     HTTP POST /points/add
    // @RequestBody : HTTP 요청 본문(JSON)을 DTO로 역직렬화
    @PostMapping("add")
    public ResponseEntity<Void> addPoints(
          @RequestBody AddPointRequestDto addPointRequestDto
    ) {
        pointService.addPoints(addPointRequestDto);
        return ResponseEntity.noContent().build();
    }

    // 포인트 차감 API
    /*
        사용 시나리오
            - 포인트로 상품 구매
            - 포인트 사용 이벤트
            - 관리자의 포인트 회수
     */
    @PostMapping("deduct")      // POST /points/deduct 요청 매핑
    public ResponseEntity<Void> deductPoints(
           @RequestBody DeductPointRequestDto deductPointRequestDto
    ) {
        pointService.deductPoints(deductPointRequestDto);
        return ResponseEntity.noContent().build();
    }
}














